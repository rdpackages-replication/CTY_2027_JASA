# Robust Local Polynomial Methods for BD Designs

The `rd2d` package implements pointwise and uniform estimation and inference for boundary discontinuity (BD) designs using local polynomial methods.

- `rd2d`: point estimation and robust bias-corrected inference using location-based methods.
- `rdbw2d`: data-driven bandwidth selection for location-based methods.
- `rd2d.distance`: point estimation and robust bias-corrected inference using distance-based methods.
- `rdbw2d.distance`: data-driven bandwidth selection for distance-based methods.

## Python Implementation

To install from PyPI:
```
python3 -m pip install rd2d
```

- Illustration: [Dataset](Python/rd2d_data.csv),
  [Numerical examples](Python/rd2d_illustration.py), [Plots](Python/rd2d_plot.py).

## R Implementation

To install/update in R, type:
```
install.packages('rd2d')
```

- Help: [R manual](https://cran.r-project.org/web/packages/rd2d/rd2d.pdf), [CRAN repository](https://CRAN.R-project.org/package=rd2d).

- Illustration: [Dataset](R/rd2d_data.csv),
  [Numerical examples](R/rd2d_illustration.R), [Plots](R/rd2d_plot.R).

## Stata Implementation

From Stata, install from GitHub with:
```
net install rd2d, from(https://raw.githubusercontent.com/rdpackages/rd2d/main/stata) replace
```

- Illustration: [Dataset](stata/rd2d_data.csv),
  [Numerical examples](stata/rd2d_illustration.do).


## References

For overviews and introductions, see [rdpackages website](https://rdpackages.github.io).


### Software and Implementation

- Cattaneo, Titiunik and Yu (2026): [rd2d: Causal Inference in Boundary Discontinuity Designs](https://rdpackages.github.io/references/Cattaneo-Titiunik-Yu_2026_rd2d.pdf).<br>
Working paper.


### Technical and Methodological

- Cattaneo, Titiunik and Yu (2026): [Boundary Discontinuity Designs: Theory and Practice](https://rdpackages.github.io/references/Cattaneo-Titiunik-Yu_2026_ESWC.pdf).<br>
Advances in Economics and Econometrics: Thirteenth World Congress, eds. R. Griffith, Y. Gorodnichenko, M. Kandori and F. Molinari, Cambridge University Press, Vol. 1, Ch. 2, to appear, 2026.

- Cattaneo, Titiunik and Yu (2027): [Estimation and Inference in Boundary Discontinuity Designs: Location-Based Methods](https://rdpackages.github.io/references/Cattaneo-Titiunik-Yu_2026_JASA.pdf).<br>
_Journal of the American Statistical Association_, revise and resubmit.<br>
[Supplemental Appendix](https://rdpackages.github.io/references/Cattaneo-Titiunik-Yu_2026_JASA--Supplement.pdf).

- Cattaneo, Titiunik and Yu (2026): [Estimation and Inference in Boundary Discontinuity Designs: Distance-Based Methods](https://rdpackages.github.io/references/Cattaneo-Titiunik-Yu_2026_JOE.pdf).<br>
_Journal of Econometrics_ 256(A): 106266.<br>
[Supplemental Appendix](https://rdpackages.github.io/references/Cattaneo-Titiunik-Yu_2026_JOE--Supplement.pdf).

- Cattaneo, Titiunik and Yu (2026): [Estimation and Inference in Boundary Discontinuity Designs: Pooling-Based Methods](https://rdpackages.github.io/references/Cattaneo-Titiunik-Yu_2026_BDD-Pooling.pdf).<br>
Working paper.<br>
[Supplemental Appendix](https://rdpackages.github.io/references/Cattaneo-Titiunik-Yu_2026_BDD-Pooling--Supplement.pdf).

## Funding

This work was supported in part by the National Science Foundation through grants [SES-2019432](https://www.nsf.gov/awardsearch/showAward?AWD_ID=2019432), [DMS-2210561](https://www.nsf.gov/awardsearch/showAward?AWD_ID=2210561), [SES-2241575](https://www.nsf.gov/awardsearch/showAward?AWD_ID=2241575), and [SES-2342226](https://www.nsf.gov/awardsearch/showAward?AWD_ID=2342226), and by the National Institute for Food and Agriculture through grant [2024-67023-42704](https://www.nifa.usda.gov/data).


<br><br>
